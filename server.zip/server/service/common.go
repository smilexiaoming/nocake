package service

import "context"

var ctx = context.Background()
