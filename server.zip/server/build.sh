swag init && go build && ./nocake
