package main

import (
	"nocake/initialize"
)

func main() {
	initialize.Run()
}
