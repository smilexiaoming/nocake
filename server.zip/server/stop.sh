killall nocake
