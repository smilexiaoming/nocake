export declare const basic: string;
